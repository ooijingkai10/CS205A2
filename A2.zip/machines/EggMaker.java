package machines;

import ingredients.Egg;
import pools.EggPool;

public class EggMaker implements Runnable{
    Task task;
    private int id;
    private int tasksDone = 0;
    private int egg_rate;
    EggPool eggPool;

    public EggMaker(Task task, int id, int egg_rate, EggPool eggPool) {
        this.task = task;
        this.id = id;
        this.egg_rate = egg_rate;
        this.eggPool = eggPool;
    }

    @Override
    public void run() {
        // TODO Auto-generated method stub
        while(task.doEggTask()) {
            Egg egg = new Egg(tasksDone, this.toString());
            try {
                Thread.sleep(egg_rate * 1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            eggPool.putEgg(egg);
            tasksDone++;
            util.Printext.log(String.format("%s puts %s",this, egg));
            task.finishBreadTask();
        }
        
    }

    @Override
    public String toString() {
        // TODO Auto-generated method stub
        return "E" + id;
    }

    public int getTasksDone() {
        return tasksDone;
    }
}
